# curso-inteligencia-artificial
Ejercicios del curso de inteligencia artificial
